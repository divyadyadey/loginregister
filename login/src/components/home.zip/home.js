import React from "react";
import { useNavigate } from "react-router-dom";
import './home.css';
function Home()
{
    const navigate=useNavigate();
    function handleClick1()
    {
        navigate('/login')
    }
    function handleClick2()
    {
        navigate('/register')
    }
    return(
        <div className="home" >
            <h1>Home page</h1>
            <h2> Already a user ?</h2>
            <button type="button"  onClick={handleClick1} > Login</button>
            <h2> New user?</h2>
            <button type="button" onClick={handleClick2}> Register</button>
        </div>
    );
}
export default Home;