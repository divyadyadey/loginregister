import React from 'react';
import './login.css';

export default function Login() {
  return(
    <div className="login-wrapper">
      <div className='login-form'> 
      <h2>Log In to continue</h2>
        <form>
          <div className="input-container">
            <label>Username: </label>
            <input type="text" name="uname" placeholder='Enter username' required />
          </div>
          
          <div className="input-container">
            <label>Password: </label>
            <input type="password" name="pass" placeholder='Enter password' required />
          </div>

          <div className="button-container">
              {/* <input type="submit" /> */}
              <button type='submit'>Login</button>
          </div>
        </form>
      </div>
    </div>
  )
}